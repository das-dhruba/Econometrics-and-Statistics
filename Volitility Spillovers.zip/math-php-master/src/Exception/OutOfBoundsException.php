<?php

namespace MathPHP\Exception;

class OutOfBoundsException extends MathException
{
}
