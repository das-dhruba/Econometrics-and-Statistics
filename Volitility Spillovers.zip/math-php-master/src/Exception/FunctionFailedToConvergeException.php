<?php

namespace MathPHP\Exception;

class FunctionFailedToConvergeException extends MathException
{
}
