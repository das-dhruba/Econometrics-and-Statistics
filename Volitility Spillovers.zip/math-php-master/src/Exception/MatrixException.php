<?php

namespace MathPHP\Exception;

class MatrixException extends MathException
{
}
