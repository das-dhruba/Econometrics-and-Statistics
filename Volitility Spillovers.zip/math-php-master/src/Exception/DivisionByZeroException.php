<?php

namespace MathPHP\Exception;

class DivisionByZeroException extends MathException
{
}
