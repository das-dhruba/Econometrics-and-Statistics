<?php

namespace MathPHP\Exception;

class BadParameterException extends MathException
{
}
