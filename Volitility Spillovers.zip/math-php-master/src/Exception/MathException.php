<?php

namespace MathPHP\Exception;

class MathException extends \Exception
{
}
