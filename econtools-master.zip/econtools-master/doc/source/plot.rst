.. currentmodule: econtools

.. _plot:

***************
Plotting Tools
***************

.. contents:: :local:


``binscatter``
--------------

See :py:func:`~econtools.binscatter`.


``legend_below``
----------------

See :py:func:`~econtools.legend_below`.
