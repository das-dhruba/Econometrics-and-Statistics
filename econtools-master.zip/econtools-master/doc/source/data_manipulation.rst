.. currentmodule: econtools

.. _data_manipulation:

***********************
Data Manipulation Tools
***********************

.. contents:: :local:

See :py:func:`~econtools.stata_merge`.

See :py:func:`~econtools.group_id`.
